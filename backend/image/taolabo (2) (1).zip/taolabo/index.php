﻿<!DOCTYPE html>
<html>
    <?php include("include/head.php");?>

    <body class="homepage">
        
        
        <!-- .header-wrapper start -->
        <div id="header-wrapper" class="clearfix">
            
            <!-- #header start -->
            <?php include("include/header.php");?><!-- .header end -->        
        </div><!-- .header-wrapper end -->

        <!-- .tp-wrapper start -->
        <div class="tp-wrapper no-bottom-margin">
            <!-- .tp-banner-container start -->
            <div class="tp-banner-container">
                <div class="tp-banner">
                    <ul>
                         <!-- slide 3 start -->
                        <li data-transition="fade" data-slotamount="7" data-masterspeed="1500">
                            <!-- main image -->
                            <img src="img/slider/slidet.jpg" alt="slidebg1" data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">

                            <!-- layer 1 -->
                            <div class="tp-caption background lft" data-x="70" data-y="140" data-speed="600" data-start="1000" data-easing="Back.easeOut" data-endspeed="300">Nous sommes le carrefour <b>Parfait</b> de votre <b>idée</b> et de <b>l'innovation</b>.
                            </div>

                            <!-- layer 2 -->
                            <div class="tp-caption background paragraph lfb" data-x="370" data-y="220" data-speed="600" data-start="2000" data-easing="Back.easeOut" data-endspeed="500">Concevons ensemble quelque chose<br> de <b>grand</b> et de <b>magnifique</b>.
                            </div>
                        </li>
                        <!-- slide 2 start -->
                        <li data-transition="fade" data-slotamount="15" data-masterspeed="1500">
                            <!-- main image -->
                            <img src="img/slider/slide-1-1.jpg" alt="slidebg3" data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">

                            <!-- layer 1 -->
                            <div class="tp-caption regular lft" data-x="220" data-y="55" data-speed="600" data-start="1000" data-easing="Back.easeOut" data-endspeed="300">Des applications <b>Professionnelles</b> et <b>Personnalisées</b> à vos besoins.
                            </div>

                            <!-- layer 2 -->
                            <div class="tp-caption regular sfl" data-x="200" data-y="120" data-speed="600" data-start="1500" data-easing="Back.easeOut" data-endspeed="300"><img src='img/slider/slide-1-2.png' alt='mobile devices'>
                            </div>

                            <!-- layer 3 -->
                            <div class="tp-caption list-right sfl" data-x="160" data-y="180" data-speed="600" data-start="2000" data-easing="Back.easeOut" data-endspeed="500"><p>Booster votre image</p>
                            </div>

                            <!-- layer 4 -->
                            <div class="tp-caption list-right sfl" data-x="70" data-y="240" data-speed="600" data-start="2300" data-easing="Back.easeOut" data-endspeed="500"><p>Pérénniser votre croissance</p>
                            </div>

                            <!-- layer 3 -->
                            <div class="tp-caption list-right sfl" data-x="60" data-y="300" data-speed="600" data-start="2600" data-easing="Back.easeOut" data-endspeed="500"><p>Optimisez vos résultats</p>
                            </div>

                            <!-- layer 4 -->
                            <div class="tp-caption list-left sfr" data-x="900" data-y="180" data-speed="600" data-start="2900" data-easing="Back.easeOut" data-endspeed="500"><p>Innovez</p>
                            </div>

                            <!-- layer 5 -->
                            <div class="tp-caption list-left sfr" data-x="870" data-y="240" data-speed="600" data-start="3200" data-easing="Back.easeOut" data-endspeed="500"><p>En continue</p>
                            </div>

                            <!-- layer 6 -->
                            <div class="tp-caption list-left sfr" data-x="840" data-y="300" data-speed="600" data-start="3500" data-easing="Back.easeOut" data-endspeed="500"><p>Avec Tao Business</p>
                            </div>
                        </li>

                        <!-- slide 2 start -->
                        <li data-transition="fade" data-slotamount="7" data-masterspeed="1500">
                            <!-- main image -->
                            <img src="img/slider/slide-2-1.jpg" alt="slidebg2" data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">

                            <!-- layer 1 -->
                            <div class="tp-caption regular lft" data-x="0" data-y="80" data-speed="600" data-start="1000" data-easing="Back.easeOut" data-endspeed="300"><b>Digitalisez</b> votre <b>Business</b> avec
                            </div>

                            <!-- layer 2 -->
                            <div class="tp-caption regular small sfl" data-x="405" data-y="130" data-speed="600" data-start="1500" data-easing="Back.easeOut" data-endspeed="300">TAO Business.
                            </div>

                            <!-- layer 3 -->
                            <div class="tp-caption sfr" data-x="520" data-y="45" data-speed="600" data-start="1500" data-easing="Back.easeOut" data-endspeed="300"><img src='img/slider/slide-2-2.png' alt='slider image'>
                            </div>

                            <!-- layer 4 -->
                            <div class="tp-caption list-left sfl" data-x="0" data-y="170" data-speed="600" data-start="2200" data-easing="Back.easeOut" data-endspeed="300"><p>Développement et hebergement Web et Mobile</p>
                            </div>

                            <!-- layer 5 -->
                            <div class="tp-caption list-left sfl" data-x="0" data-y="230" data-speed="600" data-start="2500" data-easing="Back.easeOut" data-endspeed="300"><p>Formations professionnelles en NTIC</p>
                            </div>

                            <!-- layer 6 -->
                            <div class="tp-caption list-left sfl" data-x="0" data-y="290" data-speed="600" data-start="2700" data-easing="Back.easeOut" data-endspeed="300"><p>Communication et marketing digital</p>
                            </div>
                        </li>

                       
                    </ul>
                </div><!-- .tp-banner end -->
            </div><!-- .tp-banner end -->
        </div><!-- .tp-wrapper end -->

        <!-- .page-content start -->
        <section class="page-content background-black">
            <!-- .container start -->
            <div class="container">
                <!-- .row start -->
                <div class="row">
                    <article class="grid_12">
                        <div class="triggerAnimation animated" data-animate="fadeInUp">
                            <div class="note no-bottom-margin">
                                <h4>Bienvenu chez <b>TAO Business</b>. Vous avez une idée, un projet et vous désirez passer à la vitesse supérieure grâce au Digital ?</h4>
                                <a class='btn-medium empty white' href='contact.php' style="background-color: white;"><span style="color:black;">ASSISTANCE GRATUITE</span></a>
                            </div>
                        </div><!-- .triggerAnimation.animated end -->
                    </article><!-- .grid_12 end -->
                </div><!-- .row end -->
            </div><!-- .container end -->
        </section><!-- .page-content end -->

        <!-- .page-content start -->
        <section class="page-content parallax parallax-1" data-stellar-background-ratio="0.5">
            <!-- .container start -->
            <div class="container">
                <!-- .row start -->
                <div class="row">
                    <article class="grid_12">
                        <div class="triggerAnimation animated" data-animate="fadeInLeft">
                            <ul id='services-carousel' class='carousel-li'>
                                <li class="service-box-1">
                                    <div class="icon icon-screen"></div>

                                    <a href='#'>
                                        <h5>Transformez</h5>
                                    </a>

                                    
                                </li>

                                <li class="service-box-1">
                                    <div class="icon icon-leaf"></div>

                                    <a href='#'>
                                        <h5>Améliorez</h5>
                                    </a>

                                    
                                </li>

                                <li class="service-box-1">
                                    <div class="icon icon-heart-2"></div>

                                    <a href='#'>
                                        <h5>Optimisez votre business</h5>
                                    </a>

                                    
                                </li>

                            </ul><!-- #services-carousel end -->

                            
                        </div><!-- .triggerAnimation animated end -->
                    </article><!-- .grid_12 end -->                    
                </div><!-- .row end -->
            </div><!-- .container end -->
        </section><!-- .page-content end -->

        <section class='page-content'>
            <div class="container">
                <div class="row">
                    <article class="grid_3">
                        <img class="triggerAnimation animated" src="img/pictures/logo.png" alt="ceo" data-animate="fadeInLeft">
                    </article>

                    <article class="grid_6">
                        <div class="triggerAnimation animated" data-animate="fadeInLeft">
                            <!-- .heading-bordered start -->
                            <section class="heading-bordered">
                                <h3>Ce que <b>nous Offrons</b></h3>
                            </section><!-- .heading-bordered end -->

                            <ul class="services-overview">
                                <li>
                                    <h5>Développement Web</h5>
                                    <p>
                                        Nous réalisons le développement des solutions web sur-mesure : application web, sites e-commerce et des sites internet personnalisés qui reflètent votre image de marque.
                                    </p>
                                </li>

                                <li>
                                    <h5>Marketing digital</h5>
                                    <p>
                                        Offrez une meilleure visibilité à votre marque ! Nos services en marketing digital ont pour objectif d’aider les PME etTPE à développer leurs activités. 
                                    </p>
                                </li>

                                <li>
                                    <h5>Support et maintenance</h5>
                                    <p>
                                        Obtenez un plan de maintenance de votre site Web personnalisé au meilleur prix. Nous offrons aussi des services d'hébergement web et d'espace de stockage.
                                    </p>
                                </li>

                                <li>
                                    <h5>Conception graphique</h5>
                                    <p>
                                        Nous vous aidons à réaliser des supports graphiques variés pour la présentation de votre projet, la vente de votre image de marque.
                                    </p>
                                </li>
                                <li>
                                    <h5>Formations professionnelles</h5>
                                    <p>
                                        Notre équipe d'encadreurs professionnels vous accompagne dans l'acquisition et le renforcement des compétences dans les différents domaines des NTIC.
                                    </p>
                                </li>
                            </ul>
                        </div><!-- .triggeranimation.animated end -->
                    </article><!-- .grid_6 -->

                    <article class='grid_3'>
                        <div class="triggerAnimation animated" data-animate='fadeInRight'>
                            <!-- .heading-bordered start -->
                            <section class="heading-bordered">
                                <h3>Quelques <b>chiffres</b></h3>
                            </section><!-- .heading-bordered end -->

                            <ul class='numbers-counter'>
                                <li>
                                    <span class='timer number' data-to='8' data-speed='2000'>8 ans</span>
                                    <p>Expérience</p>
                                </li>

                                <li>
                                    <span class='timer number' data-to='300' data-speed='2000'>300</span>
                                    <p>Clients</p>
                                </li>

                                <li>
                                    <span class='timer number' data-to='4' data-speed='2000'>4</span>
                                    <p>Partenaires</p>
                                </li>

                                <li>
                                    <span class='timer number' data-to='2' data-speed='2000'>2</span>
                                    <p>Pays</p>
                                </li>
                            </ul>
                        </div><!-- .triggerAnimation.animated end -->
                    </article><!-- .grid_3 end -->
                </div><!-- .row end -->
            </div><!-- .container end -->
        </section><!-- .page-content end -->

        <!-- .page-content.parallax start -->
        <section class="page-content parallax parallax-2">
            <!-- .container start -->
            <div class="container">
                <!-- .row start -->
                <div class="row">
                    <section class="grid_12">
                        <section class="heading-centered triggerAnimation animated" data-animate="bounceIn">
                            <h2>Notre <b>Processus</b> de développement</h2>
                            <p>Pensez et réalisez avec nous quelque chose d'unique, d'utilisable, avec une expérience enrichissante. Voici comment nous procédons.</p>
                        </section>
                    </section>
                </div><!-- .row end -->

                <!-- .row start -->
                <div class="row">
                    <!-- .grid_4 start -->
                    <article class="grid_4">
                        <div class="triggerAnimation animated" data-animate="fadeInLeft">
                            <section class="process-box">
                                <div class="img-container">
                                    <img src="img/pictures/development-1.png" alt="creative thinking">
                                </div>

                                <h5>Définition des objectifs</h5>
                                <p>
                                    Nous effectuerons, avec vous, une étude complète de vos besoins et de vos spécificités afin de concevoir une application web qui conviendra à vos attentes.

                                </p>
                            </section>
                        </div><!-- .triggerAnimation animated end -->
                    </article><!-- .GRID_4 END -->

                    <!-- .grid_4 start -->
                    <article class="grid_4">
                        <div class="triggerAnimation animated" data-animate="fadeInUp">
                            <section class="process-box">
                                <div class="img-container">
                                    <img src="img/pictures/development-2.png" alt="creative thinking">
                                </div>

                                <h5>Rédaction du cahier des charges</h5>
                                <p>
                                    Une fois les objectifs clairement définis, notre équipe de développeurs rédigera un cahier des charges comportant tous les détails relatifs au projet. Nous nous en servirons comme base de travail dans le but de réaliser une application web qui remplissent chacun des critères préalablement définis. Parmi ces critères : identité visuelle, stratégie de référencement, UX/UI, ergonomie, besoins techniques divers…
                                </p>
                            </section>
                        </div><!-- .triggerAnimation animated end -->
                    </article><!-- .GRID_4 END -->

                    <!-- .grid_4 start -->
                    <article class="grid_4">
                        <div class="triggerAnimation animated" data-animate="fadeInRight">
                            <section class="process-box">
                                <div class="img-container">
                                    <img src="img/pictures/development-3.png" alt="creative thinking">
                                </div>

                                <h5>Développement et déploiement de l’application</h5>
                                <p>
                                    C’est là que la magie opère. Notre équipe de développeurs décidera quelle est l’architecture la plus adaptée pour votre application. Nous ajouterons ensuite les différents volets et modules dont vous avez besoin (sécurité, frameworks, modules de paiement et d’authentification,  et autres fonctionnalités) pour que vous puissiez au mieux profiter de votre application personnalisée. Nous mettons ensuite l'application finie en ligne et nous procédons à une batterie des tests avant remise finale.

                                </p>
                            </section>
                        </div><!-- .triggerAnimation animated end -->
                    </article><!-- .GRID_4 END -->
                </div><!-- .row end -->
            </div><!-- .container end -->
        </section><!-- .page-content.parallax.parallax-2 end -->

        <section class="page-content">
            <div class="container">
                <!-- .row start -->
                <div class="row">
                    <article class="grid_12">
                        <section class="heading-centered triggerAnimation animated" data-animate="bounceIn">
                            <h2>Quelques <b>projets</b> réalisés</h2>
                            <p>Un catalogue de certains de nos projets réalisés. Vous y trouverez surement quelque chose d'intéressant.</p>
                        </section>
                    </article><!-- .grid_12 end -->

                </div><!-- .roe end -->

                <!-- .row start -->
                <div class='row'> 
                    <article class="grid_12">
                        <article class="portfolio-carousel triggerAnimation animated" data-animate="fadeInUp">
                            <ul id="portfolio-carousel" class="carousel-li">
                                <li class="isotope-item">

                                    <figure class="portfolio-img-container">
                                        <div class="portfolio-img">

                                            <img src="img/portfolio/cols/rihaplus.PNG" alt="portfolio image">


                                            <div class="portfolio-img-hover">
                                                <div class="mask"></div>

                                                <ul>
                                                    <li class="portfolio-zoom">
                                                        <a href="img/portfolio/cols/rihaplus.PNG" data-gal="prettyPhoto[pp_gallery]" class="icon-expand-2"></a>
                                                    </li>

                                                    <li class="portfolio-single">
                                                        <a href="https://rihaplus.com" class="icon-redo"></a>
                                                    </li>
                                                </ul>
                                            </div><!-- .portfolio-img-hover end -->

                                        </div>

                                        <figcaption>
                                            <a class="title" href="portfoliosingle.html">Rihaplus</a>
                                            <div class="sharre-facebook portfolio-item-like icon-heart" data-url="https://rihaplus.com/" data-text="Portefeuille electronique"></div>
                                        </figcaption>
                                    </figure>
                                </li><!-- .isotope-item end -->

                                <li class="isotope-item">

                                    <figure class="portfolio-img-container">
                                        <div class="portfolio-img">

                                            <img src="img/portfolio/cols/haya.PNG" alt="portfolio image">


                                            <div class="portfolio-img-hover">
                                                <div class="mask"></div>

                                                <ul>
                                                    <li class="portfolio-zoom">
                                                        <a href="img/portfolio/cols/haya.PNG" data-gal="prettyPhoto[pp_gallery]" class="icon-expand-2"></a>
                                                    </li>

                                                    <li class="portfolio-single">
                                                        <a href="https://haya-africa.com" class="icon-redo"></a>
                                                    </li>
                                                </ul>
                                            </div><!-- .portfolio-img-hover end -->

                                        </div>

                                        <figcaption>
                                            <a class="title" href="portfoliosingle.html">Plateforme de vente en ligne</a>
                                            <div class="sharre-facebook portfolio-item-like icon-heart" data-url="https://haya-africa.com" data-text="Plateforme de vente en ligne"></div>
                                        </figcaption>
                                    </figure>
                                </li><!-- .isotope-item end -->

                                <li class="isotope-item">

                                    <figure class="portfolio-img-container">
                                        <div class="portfolio-img">

                                            <img src="img/portfolio/cols/ivento.PNG" alt="portfolio image">


                                            <div class="portfolio-img-hover">
                                                <div class="mask"></div>

                                                <ul>
                                                    <li class="portfolio-zoom">
                                                        <a href="img/portfolio/cols/ivento.PNG" data-gal="prettyPhoto[pp_gallery]" class="icon-expand-2"></a>
                                                    </li>

                                                    <li class="portfolio-single">
                                                        <a href="https://ivento.net" class="icon-redo"></a>
                                                    </li>
                                                </ul>
                                            </div><!-- .portfolio-img-hover end -->

                                        </div>

                                        <figcaption>
                                            <a class="title" href="portfoliosingle.html">Carrefour évenementiel</a>
                                            <div class="sharre-facebook portfolio-item-like icon-heart" data-url="https://ivento.net" data-text="Carrefour évenementiel"></div>
                                        </figcaption>
                                    </figure>
                                </li><!-- .isotope-item end -->

                                <li class="isotope-item">

                                    <figure class="portfolio-img-container">
                                        <div class="portfolio-img">

                                            <img src="img/portfolio/cols/gec.PNG" alt="portfolio image">


                                            <div class="portfolio-img-hover">
                                                <div class="mask"></div>

                                                <ul>
                                                    <li class="portfolio-zoom">
                                                        <a href="img/portfolio/cols/gec.PNG" data-gal="prettyPhoto[pp_gallery]" class="icon-expand-2"></a>
                                                    </li>

                                                    <li class="portfolio-single">
                                                        <a href="https://taoglo.com" class="icon-redo"></a>
                                                    </li>
                                                </ul>
                                            </div><!-- .portfolio-img-hover end -->

                                        </div>

                                        <figcaption>
                                            <a class="title" href="portfoliosingle.html">Dashboard 1</a>
                                            <div class="sharre-facebook portfolio-item-like icon-heart" data-url="https://taoglo.com" data-text="Dashb"></div>
                                        </figcaption>
                                    </figure>
                                </li><!-- .isotope-item end -->

                                <li class="isotope-item">

                                    <figure class="portfolio-img-container">
                                        <div class="portfolio-img">

                                            <img src="img/portfolio/cols/betajeb.PNG" alt="portfolio image">


                                            <div class="portfolio-img-hover">
                                                <div class="mask"></div>

                                                <ul>
                                                    <li class="portfolio-zoom">
                                                        <a href="img/portfolio/cols/betajeb.PNG" data-gal="prettyPhoto[pp_gallery]" class="icon-expand-2"></a>
                                                    </li>

                                                    <li class="portfolio-single">
                                                        <a href="http://lms.taoglo.com" class="icon-redo"></a>
                                                    </li>
                                                </ul>
                                            </div><!-- .portfolio-img-hover end -->

                                        </div>

                                        <figcaption>
                                            <a class="title" href="portfoliosingle.html">LMS, SHOP, Activity QUEU</a>
                                            <div class="sharre-facebook portfolio-item-like icon-heart" data-url="http://lms.taoglo.com" data-text="LMS"></div>
                                        </figcaption>
                                    </figure>
                                </li><!-- .isotope-item end -->

                                
                            </ul>

                            <div class="clearfix"></div>
                            <ul class="carousel-nav">
                                <li>
                                    <a class="c_prev_2" href="#"></a> 
                                </li>
                                <li>
                                    <a class="c_next_2" href="#"></a>
                                </li>
                            </ul>
                        </article><!-- .portfolio-carousel end -->
                    </article><!-- .grid_12 end -->
                </div><!-- .row end -->
            </div><!-- .container end -->
        </section><!-- .page-content end -->

        <!-- .page-content.parallax start -->
        <section class="page-content parallax parallax-4">
            <!-- .container start -->
            <div class="container">
                <!-- .row start -->
                <div class="row">
                    <article class="grid_8">
                        <div class="triggerAnimation animated" data-animate='fadeInDown'>
                            <h1>Chez TAO Business nous placons <b>le digital</b> au coeur <b>du développement</b>.</h1>

                            <p>
                                Conception et dévéloppement des solutions digitales, formations professionnelles dans les différents domaines des TIC, visibilité de votre entreprise, incubation d'entreprises, consultance,... Autant des compétences que nous mettons à votre service.
                            </p>

                            <br>

                            <a class='btn-medium empty' href='contact.php'>Contactez-nous</a>
                        </div><!-- .triggerAnimation.animated end -->
                    </article><!-- .grid_8 end -->

                    <article class="grid_4">
                        <div class="triggerAnimation animated" data-animate='fadeInUp'>
                            <img src='img/pictures/screen.jpeg' alt='iphone'>
                        </div><!-- .triggerAnimation.animated end -->
                    </article><!-- .grid_4 end -->
                </div><!-- .row end -->
            </div><!-- .container end -->
        </section><!-- .page-content.parallax end -->

        

        <!-- .footer-wrapper start -->
        <section class="footer-wrapper">
            <!-- .footer start -->
            <footer id="footer"> 
               
                    <a href="#" class="scroll-up">Scroll</a>
                              
            </footer><!-- .footer-end -->

            <!-- .copyright-container start -->
            <div class="copyright-container">
                <!-- .container start -->
                <div class="container">
                    <!-- .row start -->
                    <div class="row">
                        <section class="grid_6">
                            <p>Copyright TAO Business 2021. All Rights Reserved.</p>
                        </section>

                        <section class="grid_6">
                            <ul class="contact-info">
                        <li>
                            <i class="icon-phone"></i>
                            <span>22 28 09 79 /</span>
                            <span>257 75 73 94 86</span>
                            <i class="icon-envelope-alt"></i>
                            <span><a href="mailto:info@taoglo.com">   info@taoglo.com</a></span>
                        </li>
                    </ul>
                        </section>
                    </div><!-- .row end -->
                </div><!-- .container end -->
            </div><!-- .copyright-container end -->

            
        </section><!-- .footer-wrapper end -->

        <!-- scripts -->
        <script src="js/jquery-1.9.1.js"></script> <!-- jQuery library -->  
        <script src="js/jquery-migrate-1.2.1.min.js"></script> <!-- jQuery migrate -->
        <script src="js/jquery.placeholder.min.js"></script><!-- jQuery placeholder fix for old browsers -->
        <script src="js/modernizr.custom.js"></script> <!-- jQuery modernizr -->
        <script src="js/jquery.dlmenu.js"></script><!-- responsive navigation -->
        <script src="js/waypoints.min.js"></script><!-- js for animating content -->
        <script src="js/retina-1.1.0.min.js"></script><!-- retina ready script -->
        <script src="rs-plugin/js/jquery.themepunch.plugins.min.js"></script><!-- revolution slider -->
        <script src="rs-plugin/js/jquery.themepunch.revolution.min.js"></script><!-- revolution slider -->
        <script src="js/jquery.stellar.min.js"></script><!-- parallax scrolling -->
        <script src="js/jquery.tweetscroll.js"></script> <!-- jQuery tweetscroll plugin -->
        <script src="js/jquery.carouFredSel-6.2.1-packed.js"></script><!-- CarouFredSel carousel plugin -->
        <script src="js/jquery.countTo.js"></script><!-- number count animation --> 
        <script src="js/jquery.prettyPhoto.js"></script> <!-- prettyPhoto lightbox -->
        <script src="style-switcher/styleSwitcher.js"></script>
		<script src="js/nicescroll.min.js"></script> <!-- Nice scroll Plugin -->
        <script src="js/include.js"></script> <!-- jQuery custom options -->

        <script>
            /* <![CDATA[ */
            jQuery(document).ready(function($) {
                'use strict';

                //REVOLUTION SLIDE
                var revapi;
                revapi = jQuery('.tp-banner').revolution(
                        {
                            delay: 5000,
                            startwidth: 1170,
                            startheight: 500,
                            hideThumbs: 10,
                            fullWidth: "on",
                            forceFullWidth: "on",
                            navigationType: "none" // bullet, thumb, none
                        });

                $('.numbers-counter').waypoint(function() {
                    // NUMBERS COUNTER START
                    $('.numbers').data('countToOptions', {
                        formatter: function(value, options) {
                            return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ',');
                        }
                    });
                    // start timer
                    $('.timer').each(count);

                    function count(options) {
                        var $this = $(this);
                        options = $.extend({}, options || {}, $this.data('countToOptions') || {});
                        $this.countTo(options);
                    } // NUMBERS COUNTER END
                },
                        {offset: '70%'}
                );

                // PRETTYPHOTO LIGHTBOX START
                if(jQuery().prettyPhoto) {
					piPrettyphoto(); 
				}
    
				function piPrettyphoto(){
					$("a[data-gal^='prettyPhoto']").prettyPhoto({
						social_tools: false,
						hook: 'data-gal'
					});
				}  

                //PORTFOLIO CAROUSEL
                //	Responsive layout, resizing the items
                $('#portfolio-carousel').carouFredSel({
                    responsive: true,
                    width: '100%',
                    height: '100%',
                    auto: false,
                    scroll: 1,
                    prev: '.c_prev_2',
                    next: '.c_next_2',
                    items: {
                        width: 400,
                        height: '100%',
                        visible: {
                            min: 1,
                            max: 4
                        }
                    }

                });

                //  Testimonial carousel Responsive layout, resizing the items
                $('#services-carousel').carouFredSel({
                    responsive: true,
                    width: '100%',
                    auto: false,
                    scroll: 1,
                    prev: '.c_prev',
                    next: '.c_next',
                    swipe: {
                        onMouse: true,
                        onTouch: true
                    },
                    items: {
                        width: 370,
                        height: 'auto',
                        visible: {
                            min: 1,
                            max: 3
                        }
                    }
                });

                //  Responsive layout, resizing the items
                $('#testimonial-carousel').carouFredSel({
                    responsive: true,
                    width: '100%',
                    auto: true,
                    scroll: 1,
                    swipe: {
                        onMouse: true,
                        onTouch: true
                    },
                    items: {
                        width: 370,
                        height: 'variable',
                        visible: {
                            min: 1,
                            max: 1
                        }
                    }
                });


            });

            /* ]]> */
        </script>
    </body>
</html>
