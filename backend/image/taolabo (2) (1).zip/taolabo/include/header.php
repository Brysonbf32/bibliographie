<!-- .header-wrapper start -->
        <div id="header-wrapper" class="clearfix">
            <!-- .top-bar start -->
            <section id="top-bar-wrapper" style="background-color: black;">
                <div id="top-bar" class="clearfix">
                    <ul class="contact-info">
                        <li>
                            <i class="icon-phone"></i>
                            <span>22 28 09 79 /</span>
                            <span>257 75 73 94 86</span>
                        </li>

                        <li>
                            <i class="icon-envelope-alt"></i>
                            <span><a href="mailto:info@taoglo.com">info@taoglo.com</a></span>
                        </li>
                    </ul><!-- .contact-info end -->

                    <!--- .social-links start -->
                    <ul class="social-links">
                        <li style="background-color: black;">
                            <a href="#" class="pixons-twitter-1"></a>
                        </li>

                        <li style="background-color: black;">
                            <a href="#" class="pixons-facebook-2"></a>
                        </li>

                        <li style="background-color: black;">
                            <a href="#" class="pixons-skype"></a>
                        </li>
                    </ul><!-- .social-links end -->
                </div><!-- .top-bar end -->
            </section><!-- .top-bar-wrapper end -->

            <!-- #header start -->
            <header id="header" class="clearfix">
                <section id="logo">
                    <a href="index.php">
                        <img src="img/logo.png" title="TAO_Business_Logo" alt="TAO Business"/>
                    </a>
                </section>

                <section id="nav-container">
                    <nav id="nav">
                        <ul>
                            <li>
                                <a href="index.php">A propos de nous</a>
                            </li>
                          <li><a href="#">Catalogue</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </nav><!-- #nav end -->                  
                </section><!-- #nav-container end -->

                <!-- #dl-menu.dl-menuwrapper start -->
                <div id="dl-menu" class='dl-menuwrapper'>
                    <button class="dl-trigger">Open Menu</button>
                    <ul class="dl-menu">
                        <li>
                            <a href="index.php">A propos de nous</a>
                        </li>
                        <li><a href="#">Catalogue</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul><!-- .dl-menu end -->
                </div><!-- #dl-menu.dl-menuwrapper end -->
            </header><!-- .header end -->        
        </div><!-- .header-wrapper end -->