    <!-- Main content -->
    <section class="content">

			<div style="height:10px;width:1000px;position:absolute;" id="ci">
			<h2>Invoice system using Codeigniter 3</h2>			
			</div>
			
    </section><!-- /.content -->

    <script> 
	$(document).ready(function(){
   		
   		$('#ci').animate({left: '100px'}, "slow");
        $('#ci').animate({fontSize: '2em'}, "slow");
        $('.ci').animate({left: '500px'}, "slow");
 
});
</script> 
<div style="position:absolute;" class="ci">
				<h4>Happy to help ! Thank you!</h4>
				<br>
				<h4>Yours <a href="http://www.facebook.com/eboominathan" target="_blank">Boominathan</a></h4>
			</div>