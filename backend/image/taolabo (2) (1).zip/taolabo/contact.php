<!DOCTYPE html>
<html>
    

<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Tao Business</title>
        <meta name="description" content="Website Demonstration version">
        <meta name="keywords" content="Tao Bu">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, width=device-width">

        <!-- stylesheets -->
        <link rel="stylesheet" href="css/grid.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/darkblue.css" />
        <link rel="stylesheet" href="css/responsive.css" />
        <link rel="stylesheet" href="css/animate.css" />
        <link rel="stylesheet" href="css/retina.css" />

        <!-- google web fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;subset=latin,latin-ext,cyrillic-ext' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700,800,900,200,100' rel='stylesheet' type='text/css'>

        <!-- Icons -->
        <link rel="stylesheet" href="pixons/style.css" />
        <link rel="stylesheet" href="iconsfont/iconsfont.css" />

        <link rel="stylesheet" href="style-switcher/styleSwitcher.css"/>

        <!--[if lt IE 9]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->

        <!--[if lt IE 9]>
            <script src="js/selectivizr-min.js"></script>
        <![endif]-->

    </head>

    <body>
               
        <!-- .header-wrapper start -->
        <?php include("include/header.php");?>
        <!-- .header-wrapper end -->

        <!-- #page-title start -->
        <section id="page-title" class="page-title-1" data-stellar-background-ratio="0.5">
                <div class="container">
                    <div class="row">
                        <div class="grid_8">
                            <div class="pt-title triggerAnimation animated" data-animate="fadeInLeft">
                                <h2>Nous sommes là pour<span class="strong">répondre</span> à toutes vos préoccupations 24/7.<br /></h2>
                            </div>
                        </div><!-- .grid_6 end -->

                        <!-- .grid_6 start -->
                        <div class="grid_4">
                            <div class="pt-image-container">
                                <div class="pt-image triggerAnimation animated" data-animate="fadeInRight">
                                    <img src="img/page-titles/contact-page-title.png" alt="contact us" />
                                </div>
                            </div>
                        </div>
                    </div><!-- .row end -->

                </div><!-- .container end -->
        </section><!-- #page-title end -->

        <!-- .page-content start -->
        <section class="page-content">
            <!-- .container start -->
            <div class="container">
                
                <!-- .row start -->
                <div class="row">
                    <!-- .grid_6 start -->
                    <article class="grid_6">
                        <div class="triggerAnimation animated" data-animate="fadeInLeft">
                            <section class="heading-bordered">
                                <h3><b>Entrez en contact avec nous</b></h3>
                            </section><!-- .heading-bordered end -->

                            <p style="text-align: justify; font-size:15px;">
                                Vous avez un projet ? Et vous souhaitez obtenir un prix ? Un tarif ? Ou une estimation ?
                                <br /><br />

                                Pour obtenir une proposition chiffrée et détaillée de votre projet, il vous suffit de remplir le formulaire ou de nous contacter directement.
                            </p>

                            <br /><br />

                            <ul class="contact-info-list">
                                <li>
                                    <p>
                                        <i class="icon-home"></i>
                                        <span class="strong">Address: </span>
                                        Burundi, Bujumbura, Bld Melchior NDADAYE, Immeuble Peace Corner, C8
                                    </p>
                                </li>

                                <li>
                                    <p>
                                        <i class="icon-phone"></i>
                                        <span>22 28 09 79 /</span>
                                        <span>257 75 73 94 86</span>
                                    </p>
                                </li>

                        </div><!-- .animated .fadeInRight -->
                    </article><!-- .grid_6 end -->

                    <!-- .grid_6 start -->
                    <article class="grid_6">
                        <div class="triggerAnimation animated" data-animate="fadeInRight">
                            <section class="heading-bordered">
                                <h3>Laissez-nous un message</h3>
                            </section><!-- .heading-bordered end -->

                            <!-- wpcf7 start -->
                            <form class="wpcf7">
                                <fieldset>
                                    <label><span class="text-color">*</span> Nom:</label>
                                    <input type="text" class="wpcf7-text" id="contact-name"/>
                                </fieldset>

                                <fieldset>
                                    <label><span class="text-color">*</span> Email:</label>
                                    <input type="email" name="email" id="contact-email" class="wpcf7-text" />
                                </fieldset>

                                <fieldset>
                                    <label><span class="text-color">*</span> Message:</label>
                                    <textarea rows="5" class="wpcf7-textarea" id="contact-message"></textarea>
                                </fieldset>

                                <input type="submit" class="wpcf7-submit" value="Envoyer" />

                            </form><!-- wpcf7 end -->
                        </div><!-- .animated.fadeInRight end -->
                    </article><!-- .grid_6 end -->
                </div><!-- .row end -->
            </div><!-- .container end -->
        </section><!-- .page-content end -->

        <!-- .footer-wrapper start -->
        <section class="footer-wrapper">
            <!-- .footer start -->
        <footer id="footer">
                <!-- .container start -->
                <div class="container">
                    <!-- .row start -->
                    <div class="row">
                         <!-- .copyright-container start -->
            <div class="">
                <!-- .container start -->
               
                        <section class="grid_6">
                            <p>Copyright Tao Business 2020. All Rights Reserved.</p>
                        </section>

                        <section class="grid_6">
                            <div class="footer-breadcrumbs">
                                <a href="index-2.html">A propos de nous</a>
                                <a href="about.html">Catalogue</a>
                                <a href="services.html">Contact</a>
                            </div>
                        </section>
                    
            </div><!-- .copyright-container end -->

                       
                    </div><!-- .row end -->
                </div><!-- .container end -->                
            </footer><!-- .footer-end -->

           

            <a href="#" class="scroll-up">Scroll</a>
        </section><!-- .footer-wrapper end -->

        <!-- scripts -->
        <script  src="js/jquery-1.9.1.js"></script> <!-- jQuery library -->  
        <script  src="js/jquery-migrate-1.2.1.min.js"></script> <!-- jQuery migrate -->
        <script  src="js/jquery.placeholder.min.js"></script><!-- jQuery placeholder fix for old browsers -->
        <script  src="http://maps.google.com/maps/api/js?sensor=true"></script> <!-- google maps -->
        <script  src="js/jquery.ui.map.full.min.js"></script> <!-- jquery plugin for google maps -->
        <script  src="js/modernizr.custom.js"></script> <!-- jQuery modernizr -->
        <script  src="js/jquery.dlmenu.js"></script><!-- responsive navigation -->
        <script  src="js/waypoints.min.js"></script><!-- js for animating content -->
        <script  src="js/retina-1.1.0.min.js"></script><!-- retina ready script -->
        <script  src="js/jquery.stellar.min.js"></script><!-- parallax scrolling -->
        <script  src="js/jquery.tweetscroll.js"></script> <!-- jQuery tweetscroll plugin -->
        <script  src="style-switcher/styleSwitcher.js"></script>
		<script  src="js/nicescroll.min.js"></script> <!-- Nice scroll Plugin -->
        <script  src="js/include.js"></script> <!-- jQuery custom options -->

        <script>
            /* <![CDATA[ */
            jQuery(document).ready(function($) {
                'use strict';

                // GOOGLE MAPS START
                $(function() {
                    //google maps

                    var yourStartLatLng = new google.maps.LatLng(40.74843, -73.985655);
                    $('.map_canvas').gmap({'center': yourStartLatLng, 'zoom': 13, 'disableDefaultUI': true, 'callback': function() {
                            var self = this;
                            self.addMarker({'position': this.get('map').getCenter()});
                        }});
                }); // GOOGLE MAPS END

                // CONTACT FORM AJAX SUBMIT START
                $('.wpcf7 .wpcf7-submit').on('click', function(event) {
                    event.preventDefault();
                    var name = $('#contact-name').val();
                    var email = $('#contact-email').val();
                    var message = $('#contact-message').val();
                    var form_data = new Array({'Name': name, 'Email': email, 'Message': message});
                    $.ajax({
                        type: 'POST',
                        url: "contact.php",
                        data: ({'action': 'contact', 'form_data': form_data})
                    }).done(function(data) {
                        alert(data);
                    });
                }); // CONTACT FORM AJAX SUBMIT END
            });

            /* ]]> */
        </script>
    </body>

<!-- Mirrored from pixel-industry.com/html/elvyre/stretched/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 Jul 2020 18:03:16 GMT -->
</html>
