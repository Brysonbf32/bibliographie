<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>TAO Business</title>
        <meta name="description" content="TAO Business">
        <meta name="author" content="tao-business">
        <meta name="keywords" content="Tao, Digital, Tao Business, tao_business">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, width=device-width">

        <!-- stylesheets -->
        <link rel="stylesheet" href="css/grid.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/darkblue.css">
        <link rel="stylesheet" href="css/responsive.css">
        <link rel="stylesheet" href="css/animate.css">
        <link rel="stylesheet" href="css/retina.css">

        <!-- Revolution slider -->
        <link rel="stylesheet" href="rs-plugin/css/settings.css">
        <link rel="stylesheet" href="rs-plugin/css/theme-settings.css">

        <!-- prettyPhoto lightbox stylesheer -->
        <link rel="stylesheet" href="css/prettyPhoto.css" media="screen">

        <!-- google web fonts -->
        <link href='../../../css.css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;subset=latin,latin-ext,cyrillic-ext' rel='stylesheet' type='text/css'>
        <link href='../../../css-1.css?family=Raleway:400,300,500,600,700,800,900,200,100' rel='stylesheet' type='text/css'>

        <!-- Icons -->
        <link rel="stylesheet" href="pixons/style.css">
        <link rel="stylesheet" href="iconsfont/iconsfont.css">
        
        <link rel="stylesheet" href="style-switcher/styleSwitcher.css">

        <!--[if lt IE 9]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->

        <!--[if lt IE 9]>
            <script src="js/selectivizr-min.js"></script>
        <![endif]-->

    </head>