<!DOCTYPE html>
<html>
    

<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Peter K. Art</title>
        <meta name="description" content="Website Demonstration version">
        <meta name="keywords" content="Peter K, Art, Dessin, Peinture, Burundi">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, width=device-width">

        <!-- stylesheets -->
        <link rel="stylesheet" href="css/grid.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/darkblue.css" />
        <link rel="stylesheet" href="css/responsive.css" />
        <link rel="stylesheet" href="css/animate.css" />
        <link rel="stylesheet" href="css/retina.css" />

        <!-- prettyPhoto lightbox stylesheer -->
        <link rel="stylesheet" href="css/prettyPhoto.css" media="screen" />

        <!-- Nivo slider stylesheer -->
        <link rel="stylesheet" href="css/nivo-slider.css"/>

        <!-- google web fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;subset=latin,latin-ext,cyrillic-ext' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700,800,900,200,100' rel='stylesheet' type='text/css'>

        <!-- Icons -->
        <link rel="stylesheet" href="pixons/style.css" />
        <link rel="stylesheet" href="iconsfont/iconsfont.css" />

        <link rel="stylesheet" href="style-switcher/styleSwitcher.css"/>

        <!--[if lt IE 9]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->

        <!--[if lt IE 9]>
            <script src="js/selectivizr-min.js"></script>
        <![endif]-->

    </head>

    <body>
               
        <!-- .header-wrapper start -->
        <?php include("include/header.php");?><!-- .header-wrapper end -->

        <!-- #page-title start -->
        <section id="page-title" class="page-title-1" data-stellar-background-ratio="0.5">
            <div class="container">
                <div class="row">
                    <div class="grid_8">
                        <div class="pt-title triggerAnimation animated" data-animate="fadeInLeft">
                            <h1>Je suis <span class="strong">passionné</span> par le dessin <br />
                                explorez notre catalogue des réalisations.</h1>
                        </div>
                    </div><!-- .grid_6 end -->

                    <!-- .grid_6 start -->
                    <div class="grid_4">
                        <div class="pt-image-container">
                            <div class="pt-image triggerAnimation animated" data-animate="fadeInRight">
                                <img class="float-right" src="img/page-titles/portfolio-page-title.png" alt="portfolio page title image" />
                            </div>
                        </div>
                    </div>
                </div><!-- .row end -->
            </div><!-- .container end -->
        </section><!-- #page-title end -->

        <!-- .page-content start -->
        <section class="page-content">

            <!-- .container start -->
            <div class="container">

                <!-- .row start -->
                <div class="row portfolio-filters triggerAnimation animated" data-animate="fadeInDown">
                    <section class="grid_12">
                        <ul id="filters">
                            <li class="active"><a href="#" data-filter="*">All <span class="item-number">6</span></a></li>
                            <li><a href="#" data-filter=".design">Web design <span class="item-number">2</span></a></li>
                            <li><a href="#" data-filter=".photography">Photography <span class="item-number">2</span></a></li>
                            <li><a href="#" data-filter=".graphics">Graphics <span class="item-number">2</span></a></li>
                        </ul>
                    </section><!-- .grid_12 end -->                    
                </div><!-- .row.portfolio-filters end  end -->

                <!-- .row.portfolio-items-holder start -->
                <div class="row portfolio-items-holder triggerAnimation animated" data-animate="fadeInUp">

                    <!-- #portfolioitems.isotope start -->
                    <ul id="portfolioitems" class="isotope">

                        <li class="grid_6 isotope-item photography">

                            <figure class="portfolio-img-container">
                                <div class="portfolio-img">
                                    <img src="img/portfolio/cols/portfolio-1.jpg" alt="portfolio image"/>

                                    <div class="portfolio-img-hover">
                                        <div class="mask"></div>

                                        <ul>
                                            <li class="portfolio-zoom">
                                                <a href="img/portfolio/cols/portfolio-1.jpg" 
                                                   data-gal="prettyPhoto[pp_gallery]" class="icon-expand-2"></a>
                                            </li>

                                            <li class="portfolio-single">
                                                <a href="portfoliosingle.html" class="icon-redo"></a>
                                            </li>
                                        </ul>
                                    </div><!-- .portfolio-img-hover end -->

                                </div>

                                <figcaption>
                                    <a class="title" href="portfoliosingle.html">Running notes</a>
                                    <div class="sharre-facebook portfolio-item-like icon-heart" data-url="http://www.pixel-industry.com/" data-text="Just an example of sharing your portfolio image"></div>
                                </figcaption>
                            </figure>
                        </li><!-- .grid_6.isotope-item.design end -->

                        <li class="grid_6 isotope-item design">

                            <figure class="portfolio-img-container">
                                <div class="portfolio-img">
                                    <img src="img/portfolio/cols/portfolio-2.jpg" alt="portfolio image"/>

                                    <div class="portfolio-img-hover">
                                        <div class="mask"></div>

                                        <ul>
                                            <li class="portfolio-zoom">
                                                <a href="img/portfolio/cols/portfolio-2.jpg" 
                                                   data-gal="prettyPhoto[pp_gallery]" class="icon-expand-2"></a>
                                            </li>

                                            <li class="portfolio-single">
                                                <a href="portfoliosingle.html" class="icon-redo"></a>
                                            </li>
                                        </ul>
                                    </div><!-- .portfolio-img-hover end -->

                                </div>

                                <figcaption>
                                    <a class="title" href="portfoliosingle.html">On the top of the world</a>
                                    <div class="sharre-facebook portfolio-item-like icon-heart" data-url="http://themeforest.net/item/elvyre-professional-corporate-psd-template/6218124" data-text="Just an example of sharing your portfolio image"></div>
                                </figcaption>
                            </figure>
                        </li><!-- .grid_6.isotope-item.design end -->

                        <li class="grid_6 isotope-item graphics">

                            <figure class="portfolio-img-container">
                                <div class="portfolio-img">
                                    <img src="img/portfolio/cols/portfolio-3.jpg" alt="portfolio image"/>

                                    <div class="portfolio-img-hover">
                                        <div class="mask"></div>

                                        <ul>
                                            <li class="portfolio-zoom">
                                                <a href="img/portfolio/cols/portfolio-3.jpg" 
                                                   data-gal="prettyPhoto[pp_gallery]" class="icon-expand-2"></a>
                                            </li>

                                            <li class="portfolio-single">
                                                <a href="portfoliosingle.html" class="icon-redo"></a>
                                            </li>
                                        </ul>
                                    </div><!-- .portfolio-img-hover end -->

                                </div>

                                <figcaption>
                                    <a class="title" href="portfoliosingle.html">Parallel universe</a>
                                    <div class="sharre-facebook portfolio-item-like icon-heart" data-url="http://themeforest.net/item/metropolis-clean-multipurpose-wordpress-theme/6050528" data-text="Just an example of sharing your portfolio image"></div>
                                </figcaption>
                            </figure>
                        </li><!-- .grid_6.isotope-item.design end -->

                        <li class="grid_6 isotope-item design">

                            <figure class="portfolio-img-container">
                                <div class="portfolio-img">
                                    <img src="img/portfolio/cols/portfolio-4.jpg" alt="portfolio image"/>

                                    <div class="portfolio-img-hover">
                                        <div class="mask"></div>

                                        <ul>
                                            <li class="portfolio-zoom">
                                                <a href="img/portfolio/cols/portfolio-4.jpg" 
                                                   data-gal="prettyPhoto[pp_gallery]" class="icon-expand-2"></a>
                                            </li>

                                            <li class="portfolio-single">
                                                <a href="portfoliosingle.html" class="icon-redo"></a>
                                            </li>
                                        </ul>
                                    </div><!-- .portfolio-img-hover end -->

                                </div>

                                <figcaption>
                                    <a class="title" href="portfoliosingle.html">Grow creativiry</a>
                                    <div class="sharre-facebook portfolio-item-like icon-heart" data-url="http://themeforest.net/item/thalassa-extensive-html5-template/6012626" data-text="Just an example of sharing your portfolio image"></div>
                                </figcaption>
                            </figure>
                        </li><!-- .grid_6.isotope-item.design end -->

                        <li class="grid_6 isotope-item photography">

                            <figure class="portfolio-img-container">
                                <div class="portfolio-img">
                                    <img src="img/portfolio/cols/portfolio-5.jpg" alt="portfolio image"/>

                                    <div class="portfolio-img-hover">
                                        <div class="mask"></div>

                                        <ul>
                                            <li class="portfolio-zoom">
                                                <a href="img/portfolio/cols/portfolio-5.jpg" 
                                                   data-gal="prettyPhoto[pp_gallery]" class="icon-expand-2"></a>
                                            </li>

                                            <li class="portfolio-single">
                                                <a href="portfoliosingle.html" class="icon-redo"></a>
                                            </li>
                                        </ul>
                                    </div><!-- .portfolio-img-hover end -->

                                </div>

                                <figcaption>
                                    <a class="title" href="portfoliosingle.html">Inner child</a>
                                    <div class="sharre-facebook portfolio-item-like icon-heart" data-url="http://themeforest.net/item/cleanbiz-multipurpose-wordpress-theme/4935456" data-text="Just an example of sharing your portfolio image"></div>
                                </figcaption>
                            </figure>
                        </li><!-- .grid_6.isotope-item.design end -->

                        <li class="grid_6 isotope-item graphics">

                            <figure class="portfolio-img-container">
                                <div class="portfolio-img">
                                    <img src="img/portfolio/cols/portfolio-6.jpg" alt="portfolio image"/>

                                    <div class="portfolio-img-hover">
                                        <div class="mask"></div>

                                        <ul>
                                            <li class="portfolio-zoom">
                                                <a href="img/portfolio/cols/portfolio-6.jpg" 
                                                   data-gal="prettyPhoto[pp_gallery]" class="icon-expand-2"></a>
                                            </li>

                                            <li class="portfolio-single">
                                                <a href="portfoliosingle.html" class="icon-redo"></a>
                                            </li>
                                        </ul>
                                    </div><!-- .portfolio-img-hover end -->

                                </div>

                                <figcaption>
                                    <a class="title" href="portfoliosingle.html">Fresh ideas</a>
                                    <div class="sharre-facebook portfolio-item-like icon-heart" data-url="http://themeforest.net/item/alexx-multipurpose-wordpress-theme/3951507" data-text="Just an example of sharing your portfolio image"></div>
                                </figcaption>
                            </figure>
                        </li><!-- .grid_6.isotope-item.design end -->
                    </ul><!-- #portfolioitems.isotope end -->

                </div><!-- .row.portfolio-items-holder start -->

                <!-- .roe start -->
                <div class="row">
                    <div class="grid_12 pagination">
                        <ul>
                            <li class="current-page">
                                <span>Page 1 of 5</span>
                            </li>

                            <li class="active"><a href="#">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">4</a></li>
                            <li><a href="#">5</a></li>
                            <li><a href="#" class=" icon-double-angle-right"></a></li>
                        </ul>
                    </div><!-- .grid_12 end -->
                </div><!-- .row end -->
            </div><!-- .container end -->
        </section><!-- .page-content end -->

        <!-- .footer-wrapper start -->
        <section class="footer-wrapper">
            <!-- .footer start -->
          <footer id="footer">
                <!-- .container start -->
                <div class="container">
                    <!-- .row start -->
                    <div class="row">
                         <!-- .copyright-container start -->
            <div class="">
                <!-- .container start -->
               
                        <section class="grid_6">
                            <p>Copyright Tao Business 2020. All Rights Reserved.</p>
                        </section>

                        <section class="grid_6">
                            <div class="footer-breadcrumbs">
                                <a href="index.html">A propos de nous</a>
                                <a href="catalogue.html">Catalogue</a>
                                <a href="contact.html">Contact</a>
                            </div>
                        </section>
                    
            </div><!-- .copyright-container end -->

                       
                    </div><!-- .row end -->
                </div><!-- .container end -->                
            </footer><!-- .footer-end -->

            <!-- .copyright-container start -->
           

            <a href="#" class="scroll-up">Scroll</a>
        </section><!-- .footer-wrapper end -->

        <!-- scripts -->
        <script  src="js/jquery-1.9.1.js"></script> <!-- jQuery library -->  
        <script  src="js/jquery-migrate-1.2.1.min.js"></script> <!-- jQuery migrate -->
        <script  src="js/jquery.placeholder.min.js"></script><!-- jQuery placeholder fix for old browsers -->
        <script  src="js/modernizr.custom.js"></script> <!-- jQuery modernizr -->
        <script  src="js/jquery.dlmenu.js"></script><!-- responsive navigation -->
        <script  src="js/waypoints.min.js"></script><!-- js for animating content -->
        <script  src="js/retina-1.1.0.min.js"></script><!-- retina ready script -->
        <script  src="js/jquery.stellar.min.js"></script><!-- parallax scrolling -->
        <script  src="js/jquery.isotope.min.js"></script><!-- jQuery isotope plugin -->
        <script  src="js/portfolio.js"></script> <!-- jQuery portfolio options -->
        <script  src="js/jquery.prettyPhoto.js"></script> <!-- prettyPhoto lightbox -->
        <script  src="js/jquery.tweetscroll.js"></script> <!-- jQuery tweetscroll plugin -->
        <script  src="sharre/jquery.sharrre-1.3.4.min.js"></script><!-- Sharre post plugin -->
        <script  src="style-switcher/styleSwitcher.js"></script>
		<script  src="js/nicescroll.min.js"></script> <!-- Nice scroll Plugin -->
        <script  src="js/include.js"></script> <!-- jQuery custom options -->

        <script>
            /* <![CDATA[ */
            jQuery(document).ready(function($) {
                'use strict';

                // PRETTYPHOTO LIGHTBOX START
                if(jQuery().prettyPhoto) {
					piPrettyphoto(); 
				}
    
				function piPrettyphoto(){
					$("a[data-gal^='prettyPhoto']").prettyPhoto({
						social_tools: false,
						hook: 'data-gal'
					});
				}  

                //JQUERY SHARRE PLUGIN END
                $('.sharre-facebook').sharrre({
                    share: {
                        facebook: true
                    },
                    enableHover: false,
                    enableTracking: true,
                    click: function(api, options) {
                        api.simulateClick();
                        api.openPopup('facebook');
                    }
                });

            });

            /* ]]> */
        </script>
    </body>

<!-- Mirrored from pixel-industry.com/html/elvyre/stretched/portfolio2.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 Jul 2020 18:02:17 GMT -->
</html>
